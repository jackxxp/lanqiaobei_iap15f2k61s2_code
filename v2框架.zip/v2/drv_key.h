//drv_key.h
#ifndef __DRV_KEY_H__
#define __DRV_KEY_H__

#include "sys_main.h"

void drv_key_run();
uint8 drv_key_get();

#endif