//drv_other.h
#ifndef __DRV_OTHER_H__
#define __DRV_OTHER_H__

#include "sys_main.h"

void drv_other_run();
void relay_set(uint8 sw);
void buzz_set(uint8 sw);



#endif