//app_main.h
#ifndef __APP_MAIN_H__
#define __APP_MAIN_H__

#include "sys_main.h"

void app_main_run(void);

#endif

